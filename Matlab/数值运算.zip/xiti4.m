p1=[1 -3 0 1 2];
p2=[1 -2 0 4];
p=polyder(p1)
p=polyder(p1,p2)
[p3 p4]=polyder(p1,p2)
