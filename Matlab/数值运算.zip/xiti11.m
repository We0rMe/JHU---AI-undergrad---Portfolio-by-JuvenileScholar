clear
fun=@(x)(x*x-8*x+12);
x0=0;
[x1,y0]=fzero(fun,x0)
x0=7;
[x2,y0]=fzero(fun,x0)
y1=fun(x1)
y2=fun(x2)