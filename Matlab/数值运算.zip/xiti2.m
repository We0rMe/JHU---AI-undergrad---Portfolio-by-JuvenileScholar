x1=3;
x=[0:2:8];
p=[1 0 -2 4 -6];
y1=polyval(p,x1)
y=polyval(p,x)