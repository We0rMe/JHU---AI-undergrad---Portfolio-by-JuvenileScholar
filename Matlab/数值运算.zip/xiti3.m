p=[1 0 -2 4 -6];
r=roots(p)
p1=poly(r)