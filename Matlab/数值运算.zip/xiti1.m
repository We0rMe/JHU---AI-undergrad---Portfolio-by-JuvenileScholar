A=[1 -3 0 5 1];
B=[0 1 2 0 -6];
C=[1 2 0 -6];
p1=poly2sym(A+B)
p2=poly2sym(A-B)
p3=poly2sym(conv(A,B))
[q,r]=deconv(A,C)
p4=conv(q,C)+r