a=[0 1 1];
b=[1 -7 12];
[r,p,k]=residue(a,b)
[a1,b1]=residue(r,p,k)