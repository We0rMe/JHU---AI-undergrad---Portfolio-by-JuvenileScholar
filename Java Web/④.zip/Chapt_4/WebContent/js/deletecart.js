var links=document.getElementsByClassName("link");
for(var i=0;i<links.length;i++){
	var gid=links[i].getAttribute("id");
	links[i].href="javascript:void(0);onClick=deletetocart("+gid+")";
}
function deletetocart(gid){
	window.location.href="DeleteCartServlet?gid="+gid;
}