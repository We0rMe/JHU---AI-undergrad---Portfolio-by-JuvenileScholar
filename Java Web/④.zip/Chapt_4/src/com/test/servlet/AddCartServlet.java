package com.test.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.bean.Cart;
import com.test.bean.Goods;
import com.test.dao.GoodsDao;
/**
 * Servlet implementation class AddCartServlet
 */
@WebServlet("/AddCartServlet")
public class AddCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		response.setHeader("Content-type","text/html;charset=utf-8") ;
		String gid=request.getParameter("gid");
		String gcount=request.getParameter("gcount");
		if(gid!=null&&gcount!=null) {
			Goods goods=new Goods();
			GoodsDao goodsdao=new GoodsDao();
			goods=goodsdao.setGoods(Integer.parseInt(gid));
			goods.setGcount(Integer.parseInt(gcount));
			HttpSession session=request.getSession();
			Cart cart=(Cart)session.getAttribute("cart");
			if(cart!=null) {
				cart.addGoods(goods);
			}else {
				cart =new Cart();
				cart.addGoods(goods);
			}
			session.setAttribute("cart", cart);
			response.getWriter().println("���ӳɹ�");
			response.getWriter().println("<a href='cart.jsp'>�鿴���ﳵ</a>");
			response.getWriter().println("<a href='javascript:history.back(-1)'>������һҳ</a>");
		}else {
			response.getWriter().println("��������ȷ");
			response.getWriter().println("<a href='javascript:history.back(-1)'>������һҳ</a>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
