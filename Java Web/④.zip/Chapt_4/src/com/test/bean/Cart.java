package com.test.bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Cart implements Serializable {
	private 	ArrayList<Goods>goodslist=new ArrayList<Goods>();
	public ArrayList<Goods> getGoodslist() {
		return goodslist;
	}
	public void setGoodslist(ArrayList<Goods> goodslist) {
		this.goodslist = goodslist;
	}
	
	public int getGcount() {
		int count=0;
		for(int i=0;i<goodslist.size();i++) {
			count+=goodslist.get(i).getGcount();
		}
		return count;
	}
	
	public double getTotal() {
		double sum=0;
		for(int i=0;i<goodslist.size();i++) {
			sum+=goodslist.get(i).getGprice()*goodslist.get(i).getGcount();
		}
		return sum;
	}
	
	public int check(int gid) {
		int index=-1;
		for(int i=0;i<goodslist.size();i++) {
			if(goodslist.get(i).getGid()==gid) {
				index=i;
				break;
			}
		}
		return index;
	}
	
	public void addGoods(Goods goods) {
		int gid=goods.getGid();
		int index=check(gid);
		if(index==-1) {
			goodslist.add(goods);
		}else {
			int num=goodslist.get(index).getGcount()+goods.getGcount();
			goodslist.get(index).setGcount(num);
		}
	}
	
	public void deleteGoods(int gid) {
		int index=check(gid);
		goodslist.remove(index);
	}
	
	private static final long serialVersionUID = 1L;

}
