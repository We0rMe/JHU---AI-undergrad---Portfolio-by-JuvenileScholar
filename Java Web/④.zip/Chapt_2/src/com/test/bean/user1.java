package com.test.bean;

import java.io.Serializable;

public class user1 implements Serializable {
	private int userid;
    private String username;
    private String gender;
    private int age;
    private boolean member=false;
    public int getUserid(){
    	return userid;
    }
    public String getUsername(){
    	return username;
    }
    public String getGender(){
    	return gender;
    }
    public int getAge(){
    	return age;
    }
    public void setUserid(int a){
    	this.userid=a;
    }
    public void setUsername(String a){
    	this.username=a;
    }
    public void setGender(String a){
    	this.gender=a;
    }
    public void setAge(int a){
    	this.age=a;
    }
	public boolean isMember() {
		return member;
	}
	public void setMember(boolean member) {
		this.member = member;
	}
	private static final long serialVersionUID = 1L;

}
