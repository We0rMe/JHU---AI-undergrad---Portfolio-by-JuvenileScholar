/*
Navicat MySQL Data Transfer

Source Server         : localhost_3328
Source Server Version : 50556
Source Host           : localhost:3328
Source Database       : db_gwsc

Target Server Type    : MYSQL
Target Server Version : 50556
File Encoding         : 65001

Date: 2022-05-11 01:39:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `userId` int(11) NOT NULL,
  `userName` varchar(77) DEFAULT NULL,
  `userPw` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('1', 'a', 'a');

-- ----------------------------
-- Table structure for `t_catelog`
-- ----------------------------
DROP TABLE IF EXISTS `t_catelog`;
CREATE TABLE `t_catelog` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_catelog
-- ----------------------------
INSERT INTO `t_catelog` VALUES ('1652116137033', '电脑 / 办公', 'no');
INSERT INTO `t_catelog` VALUES ('1652116141232', '家居 / 家具 / 家装 / 厨具', 'no');
INSERT INTO `t_catelog` VALUES ('1652145142520', '美妆 / 个护清洁', 'no');
INSERT INTO `t_catelog` VALUES ('1652145172752', '运动 / 户外', 'no');
INSERT INTO `t_catelog` VALUES ('1652145191752', '食品 / 酒类 /  特产', 'no');
INSERT INTO `t_catelog` VALUES ('1652145210400', '图书  / 教育', 'no');

-- ----------------------------
-- Table structure for `t_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `t_gonggao`;
CREATE TABLE `t_gonggao` (
  `id` varchar(50) NOT NULL,
  `title` varchar(77) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `shijian` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_gonggao
-- ----------------------------
INSERT INTO `t_gonggao` VALUES ('1652197616846', '本站部分商品清仓大处理了', '<p>&nbsp;明天开始清仓处理部分商品了，绝对的低价，欢迎抢购</p>', '2022-05-10 23:46');
INSERT INTO `t_gonggao` VALUES ('1652197633647', '测试系统广告测试啊测试', '<p>&nbsp;测试呢</p>', '2022-05-10 23:46');

-- ----------------------------
-- Table structure for `t_goods`
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `id` varchar(50) NOT NULL,
  `catelog_id` varchar(50) DEFAULT NULL,
  `mingcheng` varchar(500) DEFAULT NULL,
  `jieshao` varchar(5000) DEFAULT NULL,
  `fujian` varchar(500) DEFAULT NULL,
  `shichangjia` int(11) DEFAULT NULL,
  `shifoutejia` varchar(255) DEFAULT NULL,
  `tejia` int(11) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('1652145872421', '1652116137033', ' 佳能（Canon）色多功能打印机机', '<p>&nbsp;佳能（Canon）G3800大容量可加墨彩色多功能无线一体机（打印/复印/扫描/作业打印/照片打印机 Wifi ）</p>\r\n<div>黑白6000页彩色7000页/三合一/WIFI/加墨简单/3年保，详询客服。更多G系列机型(此商品不参加上述活动)查看&gt;</div>', '/upload/1652145867551.jpg', '260', '是', '230', 'no');
INSERT INTO `t_goods` VALUES ('1652146563211', '1652116137033', ' 得力（deli）智能指纹考勤机 ', '<div>得力（deli）智能指纹考勤机 免软件打卡机 自动生成报表33113</div>\r\n<div>1000枚指纹快速识别，得力经典爆款指纹考勤机，操作简单，设置方便，自动生成统计报表，高性价比之选！</div>', '/upload/1652146561636.jpg', '360', '否', '360', 'no');
INSERT INTO `t_goods` VALUES ('1652146791045', '1652116137033', ' 当贝 X3 激光投影仪', '<p>&nbsp;当贝 X3 激光投影仪家用投影机（AI画质 影院级激光 3200ANSI 64G内存 激光自动对焦 梯形校正 3D全高清）</p>', '/upload/1652146785451.jpg', '560', '否', '560', 'no');
INSERT INTO `t_goods` VALUES ('1652146866836', '1652116141232', '腻子粉界面剂18kg', '<p>&nbsp;雨虹防水 墙固彩色防潮型墙面加固剂混凝土腻子粉通用界面剂18kg</p>', '/upload/1652146862515.jpg', '140', '否', '140', 'no');
INSERT INTO `t_goods` VALUES ('1652146943324', '1652116141232', ' 好视力学习台TG032', '<p>&nbsp;好视力护眼学习台灯国AA级学生儿童阅读床头工作书桌读写led灯减蓝光TG032</p>', '/upload/1652146939835.jpg', '60', '否', '60', 'no');
INSERT INTO `t_goods` VALUES ('1652147072949', '1652145142520', ' 飞科(FLYCO) 男士电动剃须刀', '<p>&nbsp;飞科(FLYCO) 男士电动剃须刀 全身水洗干湿双剃刮胡刀 1小时快充60分钟续航 FS339</p>\r\n<div>飞科电动剃须刀自营，旋转式刮胡须刀，非手动剃须刀；整机国产正品行货，工厂直供，男士理容护理佳选。</div>', '/upload/1652147069835.jpg', '140', '否', '140', 'no');
INSERT INTO `t_goods` VALUES ('1652147168973', '1652145191752', ' 十月稻田 长粒香大米 10kg', '<p>&nbsp;十月稻田 当季新米 长粒香大米 10kg 东北大米 香米 十公斤</p>\r\n<div>【当季新米】十月稻田东北好大米，爆款直降，夏日钜惠，与美好相遇！立即猛戳》》</div>', '/upload/1652147165311.jpg', '70', '否', '70', 'no');

-- ----------------------------
-- Table structure for `t_lianjie`
-- ----------------------------
DROP TABLE IF EXISTS `t_lianjie`;
CREATE TABLE `t_lianjie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mingcheng` varchar(255) DEFAULT NULL,
  `www` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_lianjie
-- ----------------------------

-- ----------------------------
-- Table structure for `t_liuyan`
-- ----------------------------
DROP TABLE IF EXISTS `t_liuyan`;
CREATE TABLE `t_liuyan` (
  `id` varchar(44) NOT NULL,
  `neirong` varchar(5000) DEFAULT NULL,
  `liuyanshi` varchar(50) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `huifu` varchar(50) DEFAULT NULL,
  `huifushi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_liuyan
-- ----------------------------
INSERT INTO `t_liuyan` VALUES ('1652199230016', 'fd ', '2022-05-11 00:13', '1652198672712', '', '');

-- ----------------------------
-- Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `id` varchar(200) NOT NULL,
  `bianhao` varchar(200) DEFAULT NULL,
  `shijian` varchar(200) DEFAULT NULL,
  `xingming` varchar(255) DEFAULT NULL,
  `dianhua` varchar(255) DEFAULT NULL,
  `songhuodizhi` varchar(200) DEFAULT NULL,
  `fukuanfangshi` varchar(200) DEFAULT NULL,
  `jine` int(11) DEFAULT NULL,
  `zhuangtai` varchar(200) DEFAULT NULL,
  `user_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('1652203965571', '20220511013245', '2022-05-11 01:32:45', '刘三', '13645457889', '北京1', '已付款', '870', '已受理', '1652198672712');

-- ----------------------------
-- Table structure for `t_orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `t_orderitem`;
CREATE TABLE `t_orderitem` (
  `id` varchar(200) NOT NULL,
  `order_id` varchar(200) DEFAULT NULL,
  `goods_id` varchar(50) DEFAULT NULL,
  `goods_quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_orderitem
-- ----------------------------
INSERT INTO `t_orderitem` VALUES ('1652203965585', '1652203965571', '1652146563211', '1');
INSERT INTO `t_orderitem` VALUES ('1652203965595', '1652203965571', '1652145872421', '1');
INSERT INTO `t_orderitem` VALUES ('1652203965602', '1652203965571', '1652147168973', '2');
INSERT INTO `t_orderitem` VALUES ('1652203965610', '1652203965571', '1652147072949', '1');

-- ----------------------------
-- Table structure for `t_pinglun`
-- ----------------------------
DROP TABLE IF EXISTS `t_pinglun`;
CREATE TABLE `t_pinglun` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `neirong` varchar(50) DEFAULT NULL,
  `shijian` varchar(4000) DEFAULT NULL,
  `goods_id` varchar(50) DEFAULT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_pinglun
-- ----------------------------
INSERT INTO `t_pinglun` VALUES ('1', '大幅度', '2022-05-11 01:27', '1652146943324', '1652198672712');
INSERT INTO `t_pinglun` VALUES ('2', '发的', '2022-05-11 01:27', '1652146563211', '1652198672712');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` varchar(50) NOT NULL,
  `loginname` varchar(50) DEFAULT NULL,
  `loginpw` varchar(255) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(255) DEFAULT NULL,
  `nianling` varchar(255) DEFAULT NULL,
  `zhuzhi` varchar(255) DEFAULT NULL,
  `dianhua` varchar(255) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1652198672712', 'liusan', '000000', '刘三', '男', '20', '北京1', '13645457889', 'no');

-- ----------------------------
-- Table structure for `t_xinwen`
-- ----------------------------
DROP TABLE IF EXISTS `t_xinwen`;
CREATE TABLE `t_xinwen` (
  `id` varchar(50) NOT NULL,
  `biaoti` varchar(50) DEFAULT NULL,
  `jieshao` varchar(4000) DEFAULT NULL,
  `fujian` varchar(255) DEFAULT NULL,
  `fabushi` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_xinwen
-- ----------------------------
INSERT INTO `t_xinwen` VALUES ('1', '[网购安全] 如何如识别和防钓鱼网网购技巧', '钓鱼网已经是网购上当受骗的主要根源了，小谓网购4年，小分享下识别和防范钓鱼网的经验心得。钓鱼网主要是高模仿各大购物网页面，直观上看完全一样，但是我们可以重点从几个方面去突破&nbsp; 第一，最简单的，也是最实在的，看网址，例淘宝网的，正确的网址是，&nbsp;**.taobao.com/*******&nbsp; 钓鱼网**.taobao.com.**.**/******* 一定要看准 taobao.com/&nbsp;&nbsp; 此方法比较简单容易。第二、安装安全的浏览器，如360浏览器或者其他浏览器，一般购物网都推出合作浏览器，用专属浏览器购物，在遇到钓鱼网时，会提示不安全等。', '/upload/1522685604151.jpg', '2022-04-10 10:17');
INSERT INTO `t_xinwen` VALUES ('2', '[经验分享] 屌丝们必看的省钱网购经验', '<p>再物价飞涨的今天，什么都涨就工资不涨，月收入2000的屌丝们，都成了月光族。省钱成为了重中之重，本屌给你们分享吧一篇网购省钱经验。</p>\r\n<p>&bull;在淘宝上买东西，可以节省4成，主要推荐方式，用淘宝金币兑换，或者淘宝金币+部分人民币。另外可以到聚划算上买爆款，一般多是些薄利多销的产品。提醒大家网购便宜，但是不要大量购买东西，不要网购成瘾了。那样就起不到省钱作用了。买书籍到当当网或者卓越亚马逊网，可省钱3成，当当网和卓越亚马逊网是专业网上卖书的商城，全网图书均为正版图书，价格为定价的50%到80%左右，有的图书甚至还有1折的优惠，而且书籍均配有读者的点评，非常的人性化。全场免运费的政策则更是吸引了众多的图书购买者。<br />\r\n&bull;买手机数码产品，可选京东商城或淘宝电器城，可省钱指2成。京东商城是专门手机、电脑等数码产品的网上商城，淘包电器城凭借其庞大的淘宝用户也随后壮大起来，目前这两家电器商城几乎80%以上的商品均支持货到在款政策，并完全保证是正品，平均价格为实体价的70%-80%左右，享受与实体购买完全一样的售后服务哦，同时能够开具正规的票据。</p>', '/upload/1522685604152.jpg', '2022-04-10 10:18');
INSERT INTO `t_xinwen` VALUES ('3', '网购快递延误损坏 消费者维权难待解', '随着网购的普及，收发快递成为很多人生活的一部分。不过，不少消费者都遇到过快递“迟到”、快递公司违规收费等问题，同时还面临维权困难。\r\n\r\n在9日举行的第七届中国消费者保护法论坛上，中国法学会消费者权益保护法学研究会的专家认为，当前消费者反映的网购快递问题主要是投递服务延误、丢失短少、损毁等，这些问题影响了消费者的快递服务体验。', '/upload/1522685604153.jpg', '2022-04-10 10:19');
INSERT INTO `t_xinwen` VALUES ('4', '购物新体验：网购有了新体验 实体店逆袭有高招', '随着网购的普及，收发快递成为很多人生活的一部分。不过，不少消费者都遇到过快递“迟到”、快递公司违规收费等问题，同时还面临维权困难。\r\n\r\n在9日举行的第七届中国消费者保护法论坛上，中国法学会消费者权益保护法学研究会的专家认为，当前消费者反映的网购快递问题主要是投递服务延误、丢失短少、损毁等，这些问题影响了消费者的快递服务体验。', '/upload/1522685604154.jpg', '2022-04-10 10:21');
INSERT INTO `t_xinwen` VALUES ('5', '外媒称瑞士人爱从中国网购：商品丰富 价格实惠', '据瑞士德语广播电视公司网站报道，瑞士电商行业协会对来自中国的包裹洪流忧心忡忡。协会主席帕特里克·凯斯勒对瑞士零售商面临的竞争劣势提出批评：中国零售商向瑞士寄送一个2公斤以下包裹价格仅为1.7瑞郎(1瑞士法郎约合7元人民币)。“而瑞士企业在国内寄送相同包裹的价格是5瑞郎到7瑞郎。”原因是中国在邮政系统被定级为新兴国家，享受低费率优惠。', '/upload/1522685604155.jpg', '2022-04-10 10:21');
INSERT INTO `t_xinwen` VALUES ('6', '90后网购最热情：哪里价格低就去哪里', '著名咨询公司麦肯锡去年发布的报告指出，未来15年，中国将贡献全球消费增量的30%。而阿里研究院则认为，未来5年，网络购物将贡献私人消费的42%，年轻一代的消费能力更强，在众多品类上的消费高出上一代40%。', '/upload/1522685604156.jpg', '2022-04-10 10:22');
