package orm;

public class Tlianjie
{
    private int id;
    private String mingcheng;
    private String www;
    
    
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getMingcheng()
	{
		return mingcheng;
	}
	public void setMingcheng(String mingcheng)
	{
		this.mingcheng = mingcheng;
	}
	public String getWww()
	{
		return www;
	}
	public void setWww(String www)
	{
		this.www = www;
	}
    
}
