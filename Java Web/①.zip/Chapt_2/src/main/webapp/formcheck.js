/**
 * 
 */
var submit=document.getElementById("submit");
submit.onclick=function(){
	var username=document.genElementByID("username").value;
	var password=document.genElementByID("password").value;
	if(username.trim()==""){
		window.alert("用户名不能为空");
		return false;
	}
	if(password.trim()==""){
		window.alert("密码不能为空");
		return false;
	}
	return true;
}